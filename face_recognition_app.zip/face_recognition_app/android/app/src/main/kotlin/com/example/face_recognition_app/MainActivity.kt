package com.example.face_recognition_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
